from Live import welcome,load_game

print(welcome('Amit'))
load_game()